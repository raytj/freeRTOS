/*
 * Temporary file for use only during development when there are no library or
 * header files.
 */

#ifndef STDIO_H
#define STDIO_H

int sprintf(char *out, const char *format, ...);

#endif /* stdio_h */
