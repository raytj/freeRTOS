/* opensslv.h compatibility */

#ifndef WOLFSSL_OPENSSLV_H_
#define WOLFSSL_OPENSSLV_H_


/* api version compatibility */
#define OPENSSL_VERSION_NUMBER 0x0090410fL


#endif /* header */

