
void main(void);

void main(void)
{
volatile unsigned long ul;

	for( ;; )
	{
		ul++;
		ul++;
	}
}


