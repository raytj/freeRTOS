Unsupported demos are no longer distributed in the main FreeRTOS download.  
They can instead be located and individually downloaded by following the 
instructions on this page:
http://www.freertos.org/RTOS-contributed-ports.html
