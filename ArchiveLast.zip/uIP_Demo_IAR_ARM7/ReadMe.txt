If you need the demo that used to be in this directory then download FreeRTOS V8.2.3
from http://sourceforge.net/projects/freertos/files/FreeRTOS/

FreeRTOS now uses its own TCP/IP stack: http://www.FreeRTOS.org/TCP

