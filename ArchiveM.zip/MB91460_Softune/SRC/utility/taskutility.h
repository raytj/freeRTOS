#ifndef TASK_UTILITY_H
#define TASK_UTILITY_H

/* Start the task that writes the tace information to the UART. */
void vUtilityStartTraceTask( unsigned portBASE_TYPE uxPriority );

#endif

