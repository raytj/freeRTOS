/* THIS SAMPLE CODE IS PROVIDED AS IS AND IS SUBJECT TO ALTERATIONS. FUJITSU */
/* MICROELECTRONICS ACCEPTS NO RESPONSIBILITY OR LIABILITY FOR ANY ERRORS OR */
/* ELIGIBILITY FOR ANY PURPOSES.                                             */
/*                 (C) Fujitsu Microelectronics Europe GmbH                  */
/*----------------------------------------------------------------------------
  VECTORS.h


  06.10.06  1.00   UMa    Initial Version
-----------------------------------------------------------------------------*/

#ifndef VECTORS_H
#define VECTORS_H

void InitIrqLevels( void );

#endif

