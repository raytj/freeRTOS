The project from this directory has been superseded by the project documented
on the following page: http://www.freertos.org/RTOS-Xilinx-Microblaze-KC705.html

If you need the demo that used to be in this directory then download FreeRTOS V8.2.2
from http://sourceforge.net/projects/freertos/files/FreeRTOS/

