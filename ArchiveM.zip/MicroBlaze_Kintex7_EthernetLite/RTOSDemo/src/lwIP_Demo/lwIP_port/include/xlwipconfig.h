#ifndef __XLWIPCONFIG_H_
#define __XLWIPCONFIG_H_


/* This is a generated file - do not edit */

#define XLWIP_CONFIG_INCLUDE_EMACLITE 1
#endif
