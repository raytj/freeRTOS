Import this project into code composer studio using File->Import->Code Composer Studio->Existing CCS/CCE Ecplise Projects.

The project will *not* open correctly by selecting File->Import->Existing Projects into Workspace.